package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "contactDumdumPark")
public class ContactDumdumPark {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	
	public int contactid;
	public String officeLocation;
	public String  contactNumber;
	public String officialEmailaddress;
	public String visitinghours;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;
	
	public int getContactid() {
		return contactid;
	}
	public void setContactid(int contactid) {
		this.contactid = contactid;
	}
	public String getOfficeLocation() {
		return officeLocation;
	}
	public void setOfficeLocation(String officeLocation) {
		this.officeLocation = officeLocation;
	}
	public String  getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String  contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getOfficialEmailaddress() {
		return officialEmailaddress;
	}
	public void setOfficialEmailaddress(String officialEmailaddress) {
		this.officialEmailaddress = officialEmailaddress;
	}
	public String getVisitinghours() {
		return visitinghours;
	}
	public void setVisitinghours(String visitinghours) {
		this.visitinghours = visitinghours;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getCreated_by() {
		return created_by;
	}
	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public int getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	public ContactDumdumPark(int contactid, String officeLocation, String  contactNumber, String officialEmailaddress,
			String visitinghours, Date created_date, int created_by, Date update_date, int update_by) {
		this.contactid = contactid;
		this.officeLocation = officeLocation;
		this.contactNumber = contactNumber;
		this.officialEmailaddress = officialEmailaddress;
		this.visitinghours = visitinghours;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}
	public ContactDumdumPark() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
