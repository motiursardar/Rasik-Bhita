package com.sarada.rasik.bhita.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "master_manu")
public class MasterManu {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

//public class MasterManu {
	public int id;
	public int menu_id;
	public String aboutus;
	public String courses;
	public String activities;
	public String gallery;
	public String news;
	public String contactus;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "menu_id", insertable = false)
	public List<SubMenu> sub_Menu;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMenu_id() {
		return menu_id;
	}

	public void setMenu_id(int menu_id) {
		this.menu_id = menu_id;
	}

	public String getAboutus() {
		return aboutus;
	}

	public void setAboutus(String aboutus) {
		this.aboutus = aboutus;
	}

	public String getCourses() {
		return courses;
	}

	public void setCourses(String courses) {
		this.courses = courses;
	}

	public String getActivities() {
		return activities;
	}

	public void setActivities(String activities) {
		this.activities = activities;
	}

	public String getGallery() {
		return gallery;
	}

	public void setGallery(String gallery) {
		this.gallery = gallery;
	}

	public String getNews() {
		return news;
	}

	public void setNews(String news) {
		this.news = news;
	}

	public String getContactus() {
		return contactus;
	}

	public void setContactus(String contactus) {
		this.contactus = contactus;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	public List<SubMenu> getSub_Menu() {
		return sub_Menu;
	}

	public void setSub_Menu(List<SubMenu> sub_Menu) {
		this.sub_Menu = sub_Menu;
	}

	public MasterManu(int id, int menu_id, String aboutus, String courses, String activities, String gallery,
			String news, String contactus, Date created_date, int created_by, Date update_date, int update_by,
			List<SubMenu> sub_Menu) {
		this.id = id;
		this.menu_id = menu_id;
		this.aboutus = aboutus;
		this.courses = courses;
		this.activities = activities;
		this.gallery = gallery;
		this.news = news;
		this.contactus = contactus;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
		this.sub_Menu = sub_Menu;
	}

	public MasterManu() {
		super();
		// TODO Auto-generated constructor stub
	}

}
