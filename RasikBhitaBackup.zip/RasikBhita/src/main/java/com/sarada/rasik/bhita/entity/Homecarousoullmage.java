package com.sarada.rasik.bhita.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "home_carousoul_image")

public class Homecarousoullmage {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int img_id;
	public int page_id;
	@Column(name = "img_path")
	public String img_path;

	public int img_seq;

	public String img_heading;

	public String img_description;

	public int img_show;

	public int img_btn;

	public String img_btn_name;

	public String img_btn_url;

	public Date created_date;

	public int created_by;

	public Date update_date;

	public int update_by;

	public int getPage_id() {
		return page_id;
	}

	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}

	public int getImg_id() {
		return img_id;
	}

	public void setImg_id(int img_id) {
		this.img_id = img_id;
	}

	public String getImg_path() {
		return img_path;
	}

	public void setImg_path(String img_path) {
		this.img_path = img_path;
	}

	public int getImg_seq() {
		return img_seq;
	}

	public void setImg_seq(int img_seq) {
		this.img_seq = img_seq;
	}

	public String getImg_heading() {
		return img_heading;
	}

	public void setImg_heading(String img_heading) {
		this.img_heading = img_heading;
	}

	public String getImg_description() {
		return img_description;
	}

	public void setImg_description(String img_description) {
		this.img_description = img_description;
	}

	public int getImg_show() {
		return img_show;
	}

	public void setImg_show(int img_show) {
		this.img_show = img_show;
	}

	public int getImg_btn() {
		return img_btn;
	}

	public void setImg_btn(int img_btn) {
		this.img_btn = img_btn;
	}

	public String getImg_btn_name() {
		return img_btn_name;
	}

	public void setImg_btn_name(String img_btn_name) {
		this.img_btn_name = img_btn_name;
	}

	public String getImg_btn_url() {
		return img_btn_url;
	}

	public void setImg_btn_url(String img_btn_url) {
		this.img_btn_url = img_btn_url;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	public Homecarousoullmage(int img_id, int page_id, String img_path, int img_seq, String img_heading,
			String img_description, int img_show, int img_btn, String img_btn_name, String img_btn_url,
			Date created_date, int created_by, Date update_date, int update_by,
			List<Homecarousoullmage> homeCarousoulImageList) {
		super();
		this.img_id = img_id;
		this.page_id = page_id;
		this.img_path = img_path;
		this.img_seq = img_seq;
		this.img_heading = img_heading;
		this.img_description = img_description;
		this.img_show = img_show;
		this.img_btn = img_btn;
		this.img_btn_name = img_btn_name;
		this.img_btn_url = img_btn_url;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
		// this.homeCarousoulImageList = homeCarousoulImageList;
	}

	public Homecarousoullmage() {
		super();
		// TODO Auto-generated constructor stub
	}

}
