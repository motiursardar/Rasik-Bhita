package com.sarada.rasik.bhita.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sarada.rasik.bhita.entity.OurOrigin;


public interface OurOriginRepo extends JpaRepository<OurOrigin, Integer> {

}
