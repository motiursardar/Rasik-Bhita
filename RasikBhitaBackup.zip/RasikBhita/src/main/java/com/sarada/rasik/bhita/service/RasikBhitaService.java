
package com.sarada.rasik.bhita.service;

import java.util.List;
import java.util.Optional;

import com.sarada.rasik.bhita.entity.AdvisoryCommittee;
import com.sarada.rasik.bhita.entity.AllCourseFee;
import com.sarada.rasik.bhita.entity.ContactDakshineswar;
import com.sarada.rasik.bhita.entity.CourseDetails;
import com.sarada.rasik.bhita.entity.CourseGroup;
import com.sarada.rasik.bhita.entity.Courses;
import com.sarada.rasik.bhita.entity.CoursesFees;
import com.sarada.rasik.bhita.entity.Homecarousoullmage;
import com.sarada.rasik.bhita.entity.MasterManu;
import com.sarada.rasik.bhita.entity.OurOrigin;
import com.sarada.rasik.bhita.entity.Pages;
import com.sarada.rasik.bhita.entity.Premises;
import com.sarada.rasik.bhita.entity.StoryOfRasik;

public interface RasikBhitaService {
	public Optional<Pages> gethomePageData(int pageId);

	public List<Pages> homecarousal();
	////////////////////////////////////////

	public List<Homecarousoullmage> getAll();

	List<CoursesFees> CoursesFees();

	public List<Courses> getAllcourses();

	List<Courses> courseListOb();

//////////////////////

	public List<CourseDetails> FinndCourseDetailsByCourseId();

	public List<CoursesFees> FinndCourseFeesByCourseId();

	public List<CourseGroup> getAllcourseGroup();

	///////////////////////////////////////

	public List<StoryOfRasik> FinndStoryOfRasik();

	List<Premises> FinndPremisesOfRasik();
//
//	List<OurOrigin> FinndOurOrigin();
//
//	List<AdvisoryCommittee> FinndOurCommittee();

	List<AllCourseFee> FinndCourseFee();

	

	List<MasterManu> masterMenudata();
	//List<ContactDakshineswar> ContactDakshineswar();

	List<ContactDakshineswar> contactDakshineswar();

	

	

}
