package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "events")

public class Events {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	public int event_id;
	public int page_id;
	public String event_name;
	public String event_start_date;
	public String event_end_date;
	public int event_active;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;
	public Events(int page_id, int event_id, String event_name, String event_start_date, String event_end_date,
			int event_active, Date created_date, int created_by, Date update_date, int update_by) {
		super();
		this.page_id = page_id;
		this.event_id = event_id;
		this.event_name = event_name;
		this.event_start_date = event_start_date;
		this.event_end_date = event_end_date;
		this.event_active = event_active;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}
	
	public Events() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPage_id() {
		return page_id;
	}
	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}
	public int getEvent_id() {
		return event_id;
	}
	public void setEvent_id(int event_id) {
		this.event_id = event_id;
	}
	public String getEvent_name() {
		return event_name;
	}
	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}
	public String getEvent_start_date() {
		return event_start_date;
	}
	public void setEvent_start_date(String event_start_date) {
		this.event_start_date = event_start_date;
	}
	public String getEvent_end_date() {
		return event_end_date;
	}
	public void setEvent_end_date(String event_end_date) {
		this.event_end_date = event_end_date;
	}
	public int getEvent_active() {
		return event_active;
	}
	public void setEvent_active(int event_active) {
		this.event_active = event_active;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getCreated_by() {
		return created_by;
	}
	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public int getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	@Override
	public String toString() {
		return "events [page_id=" + page_id + ", event_id=" + event_id + ", event_name=" + event_name
				+ ", event_start_date=" + event_start_date + ", event_end_date=" + event_end_date + ", event_active="
				+ event_active + ", created_date=" + created_date + ", created_by=" + created_by + ", update_date="
				+ update_date + ", update_by=" + update_by + "]";
	}
	

}
