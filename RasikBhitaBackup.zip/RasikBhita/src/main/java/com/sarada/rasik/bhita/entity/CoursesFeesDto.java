//package com.sarada.rasik.bhita.entity;
//
//import java.util.Date;
//
//public class CoursesFeesDto {
//
//	public int fees_id;
//
//	public int course_id;
//
//	public String course_name;
//
//	public String duration;
//
//	public int total_course_fees;
//
//	public int admission_fees;
//
//	public String fees_to_installments;
//	public int create_by;
//	public Date create_date;
//	public int update_by;
//	public Date update_date;
//
//	public CoursesFeesDto() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//	public CoursesFeesDto(int fees_id, int course_id, String course_name, String duration, int total_Course_Fees,
//			int admission_Fees, String fees_To_Installments, int create_by, Date create_date, int update_by,
//			Date update_date) {
//		this.fees_id = fees_id;
//		this.course_id = course_id;
//		this.course_name = course_name;
//		this.duration = duration;
//		this.total_course_fees = total_course_fees;
//		this.admission_fees = admission_fees;
//		this.fees_to_installments = fees_To_Installments;
//		this.create_by = create_by;
//		this.create_date = create_date;
//		this.update_by = update_by;
//		this.update_date = update_date;
//	}
//
//	public int getFees_id() {
//		return fees_id;
//	}
//
//	public void setFees_id(int fees_id) {
//		this.fees_id = fees_id;
//	}
//
//	public int getCourse_id() {
//		return course_id;
//	}
//
//	public void setCourse_id(int course_id) {
//		this.course_id = course_id;
//	}
//
//	public String getCourse_name() {
//		return course_name;
//	}
//
//	public void setCourse_name(String course_name) {
//		this.course_name = course_name;
//	}
//
//	public String getDuration() {
//		return duration;
//	}
//
//	public void setDuration(String duration) {
//		this.duration = duration;
//	}
//
//	public int gettotal_course_fees() {
//		return total_course_fees;
//	}
//
//	public void setTotal_Course_Fees(int total_course_fees) {
//		total_course_fees = total_course_fees;
//	}
//
//	public int getadmission_fees() {
//		return admission_fees;
//	}
//
//	public void setadmission_fees(int admission_fees) {
//		admission_fees = admission_fees;
//	}
//
//	public String getFees_To_Installments() {
//		return fees_to_installments;
//	}
//
//	public void setfees_To_installments(String fees_To_installments) {
//		fees_To_installments = fees_To_installments;
//	}
//
//	public int getCreate_by() {
//		return create_by;
//	}
//
//	public void setCreate_by(int create_by) {
//		create_by = create_by;
//	}
//
//	public Date getCreate_date() {
//		return create_date;
//	}
//
//	public void setCreate_date(Date create_date) {
//		create_date = create_date;
//	}
//
//	public int getUpdate_by() {
//		return update_by;
//	}
//
//	public void setUpdate_by(int update_by) {
//		update_by = update_by;
//	}
//
//	public Date getUpdate_date() {
//		return update_date;
//	}
//
//	public void setUpdate_date(Date update_date) {
//		update_date = update_date;
//	}
//
//}
