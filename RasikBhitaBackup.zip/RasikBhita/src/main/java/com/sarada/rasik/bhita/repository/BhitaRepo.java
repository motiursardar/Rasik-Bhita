
package com.sarada.rasik.bhita.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.sarada.rasik.bhita.entity.Pages;

public interface BhitaRepo extends JpaRepository<Pages, Integer> {
	
}
