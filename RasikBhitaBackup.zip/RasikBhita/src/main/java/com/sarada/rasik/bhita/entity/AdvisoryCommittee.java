package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "advisory_committee")

public class AdvisoryCommittee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	public int committee_id;
	public String advisory_commitee_h_img_pagth;
	public String advisory_commitee_b_img_pagth;
	public String commitee_text;
	public int created_by;
	public Date created_date;
	public int update_by;
	public Date update_date;
	public AdvisoryCommittee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCommittee_id() {
		return committee_id;
	}
	public void setCommittee_id(int committee_id) {
		this.committee_id = committee_id;
	}
	public String getAdvisory_commitee_h_img_pagth() {
		return advisory_commitee_h_img_pagth;
	}
	public void setAdvisory_commitee_h_img_pagth(String advisory_commitee_h_img_pagth) {
		this.advisory_commitee_h_img_pagth = advisory_commitee_h_img_pagth;
	}
	public String getAdvisory_commitee_b_img_pagth() {
		return advisory_commitee_b_img_pagth;
	}
	public void setAdvisory_commitee_b_img_pagth(String advisory_commitee_b_img_pagth) {
		this.advisory_commitee_b_img_pagth = advisory_commitee_b_img_pagth;
	}
	public String getCommitee_text() {
		return commitee_text;
	}
	public void setCommitee_text(String commitee_text) {
		this.commitee_text = commitee_text;
	}
	public int getCreated_by() {
		return created_by;
	}
	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public AdvisoryCommittee(int committee_id, String advisory_commitee_h_img_pagth,
			String advisory_commitee_b_img_pagth, String commitee_text, int created_by, Date created_date,
			int update_by, Date update_date) {
		this.committee_id = committee_id;
		this.advisory_commitee_h_img_pagth = advisory_commitee_h_img_pagth;
		this.advisory_commitee_b_img_pagth = advisory_commitee_b_img_pagth;
		this.commitee_text = commitee_text;
		this.created_by = created_by;
		this.created_date = created_date;
		this.update_by = update_by;
		this.update_date = update_date;
	}
	@Override
	public String toString() {
		return "AdvisoryCommittee [committee_id=" + committee_id + ", advisory_commitee_h_img_pagth="
				+ advisory_commitee_h_img_pagth + ", advisory_commitee_b_img_pagth=" + advisory_commitee_b_img_pagth
				+ ", commitee_text=" + commitee_text + ", created_by=" + created_by + ", created_date=" + created_date
				+ ", update_by=" + update_by + ", update_date=" + update_date + "]";
	}
	
}
