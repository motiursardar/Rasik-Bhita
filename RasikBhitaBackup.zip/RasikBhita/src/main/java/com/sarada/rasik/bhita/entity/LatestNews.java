package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import javax.persistence.Table;

@Entity
@Table(name = "latest_news")
public class LatestNews {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	  public int news_id;
	  public int page_id;
	  public String news_head;
	  public String news_body;
	  public String news_image; 
	  public int news_active;
	  public Date created_date; 
	  public int created_by; 
	  public Date update_date;
	  public int update_by;
	public LatestNews(int news_id, int page_id, String news_head, String news_body, String news_image, int news_active,
			Date created_date, int created_by, Date update_date, int update_by) {
		super();
		this.news_id = news_id;
		this.page_id = page_id;
		this.news_head = news_head;
		this.news_body = news_body;
		this.news_image = news_image;
		this.news_active = news_active;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}
	
	
	public LatestNews() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getNews_id() {
		return news_id;
	}
	public void setNews_id(int news_id) {
		this.news_id = news_id;
	}
	public int getPage_id() {
		return page_id;
	}
	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}
	public String getNews_head() {
		return news_head;
	}
	public void setNews_head(String news_head) {
		this.news_head = news_head;
	}
	public String getNews_body() {
		return news_body;
	}
	public void setNews_body(String news_body) {
		this.news_body = news_body;
	}
	public String getNews_image() {
		return news_image;
	}
	public void setNews_image(String news_image) {
		this.news_image = news_image;
	}
	public int getNews_active() {
		return news_active;
	}
	public void setNews_active(int news_active) {
		this.news_active = news_active;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getCreated_by() {
		return created_by;
	}
	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public int getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	@Override
	public String toString() {
		return "latest_news [news_id=" + news_id + ", page_id=" + page_id + ", news_head=" + news_head + ", news_body="
				+ news_body + ", news_image=" + news_image + ", news_active=" + news_active + ", created_date="
				+ created_date + ", created_by=" + created_by + ", update_date=" + update_date + ", update_by="
				+ update_by + "]";
	}
	
	  
	  
	

}
