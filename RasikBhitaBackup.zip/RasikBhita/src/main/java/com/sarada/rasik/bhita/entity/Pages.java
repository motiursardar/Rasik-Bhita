package com.sarada.rasik.bhita.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "pages")

public class Pages {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int page_id;

	public String pagename;

	public Date created_date;

	public int created_by;

	public Date update_date;

	public int update_by;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<Homecarousoullmage> homeCarousoulImageList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<Aboutus> aboutusList;

	public List<Aboutus> getAboutusList() {
		return aboutusList;
	}

	public void setAboutusList(List<Aboutus> aboutusList) {
		this.aboutusList = aboutusList;
	}

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<Activities> activitiesList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<CorporateConnect> corporateConnectList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<CorporateLogo> corporateLogoList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<Courses> coursesList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<Events> eventsList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<LatestNews> latestNewsList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<StudentProject> studentProjectList;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "page_id", insertable = false)
	public List<StudentWords> studentWordsList;

	public List<Activities> getActivitiesList() {
		return activitiesList;
	}

	public void setActivitiesList(List<Activities> activitiesList) {
		this.activitiesList = activitiesList;
	}

	public List<CorporateConnect> getCorporateConnectList() {
		return corporateConnectList;
	}

	public void setCorporateConnectList(List<CorporateConnect> corporateConnectList) {
		this.corporateConnectList = corporateConnectList;
	}

	public List<CorporateLogo> getCorporateLogoList() {
		return corporateLogoList;
	}

	public void setCorporateLogoList(List<CorporateLogo> corporateLogoList) {
		this.corporateLogoList = corporateLogoList;
	}

	public List<Courses> getCoursesList() {
		return coursesList;
	}

	public void setCoursesList(List<Courses> coursesList) {
		this.coursesList = coursesList;
	}

	public List<Events> getEventsList() {
		return eventsList;
	}

	public void setEventsList(List<Events> eventsList) {
		this.eventsList = eventsList;
	}

	public List<LatestNews> getLatestNewsList() {
		return latestNewsList;
	}

	public void setLatestNewsList(List<LatestNews> latestNewsList) {
		this.latestNewsList = latestNewsList;
	}

	public List<StudentProject> getStudentProjectList() {
		return studentProjectList;
	}

	public void setStudentProjectList(List<StudentProject> studentProjectList) {
		this.studentProjectList = studentProjectList;
	}

	public List<StudentWords> getStudentWordsList() {
		return studentWordsList;
	}

	public void setStudentWordsList(List<StudentWords> studentWordsList) {
		this.studentWordsList = studentWordsList;
	}

	public List<Homecarousoullmage> getHomeCarousoulImageList() {
		return homeCarousoulImageList;
	}

	public void setHomeCarousoulImageList(List<Homecarousoullmage> homeCarousoulImageList) {
		this.homeCarousoulImageList = homeCarousoulImageList;
	}

	public int getPage_id() {
		return page_id;
	}

	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}

	public String getPagename() {
		return pagename;
	}

	public void setPagename(String pagename) {
		this.pagename = pagename;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	public Pages() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "pages [ page_id=" + page_id + ", pagename=" + pagename + ", created_date=" + created_date
				+ ", created_by=" + created_by + ", update_date=" + update_date + ", update_by=" + update_by + "]";
	}

	public Pages(long id, int page_id, String pagename, Date created_date, int created_by, Date update_date,
			int update_by) {
		super();

		this.page_id = page_id;
		this.pagename = pagename;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}

}
