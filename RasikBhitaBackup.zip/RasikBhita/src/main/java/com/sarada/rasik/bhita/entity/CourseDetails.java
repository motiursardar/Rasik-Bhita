package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "course_details")

public class CourseDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int course_id;
	public int course_details_id;

	public String course_name;
	public String course_short_desc;
	public String course_content;
	public String course_desc;
	public String job_role;
	public String start_date;
	public int duration;
	public int course_fees;
	public String eligibility;
	public String course_img_path;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;

	public CourseDetails(int course_details_id, int course_id, String course_name, String course_short_desc,
			String course_content, String course_desc, String job_role, String start_date, int duration,
			int course_fees, String eligibility, String course_img_path, Date created_date, int created_by,
			Date update_date, int update_by) {
		this.course_details_id = course_details_id;
		this.course_id = course_id;
		this.course_name = course_name;
		this.course_short_desc = course_short_desc;
		this.course_content = course_content;
		this.course_desc = course_desc;
		this.job_role = job_role;
		this.start_date = start_date;
		this.duration = duration;
		this.course_fees = course_fees;
		this.eligibility = eligibility;
		this.course_img_path = course_img_path;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}

	public int getCourse_details_id() {
		return course_details_id;
	}

	public void setCourse_details_id(int course_details_id) {
		this.course_details_id = course_details_id;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public String getCourse_short_desc() {
		return course_short_desc;
	}

	public void setCourse_short_desc(String course_short_desc) {
		this.course_short_desc = course_short_desc;
	}

	public String getCourse_content() {
		return course_content;
	}

	public void setCourse_content(String course_content) {
		this.course_content = course_content;
	}

	public String getCourse_desc() {
		return course_desc;
	}

	public void setCourse_desc(String course_desc) {
		this.course_desc = course_desc;
	}

	public String getJob_role() {
		return job_role;
	}

	public void setJob_role(String job_role) {
		this.job_role = job_role;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getCourse_fees() {
		return course_fees;
	}

	public void setCourse_fees(int course_fees) {
		this.course_fees = course_fees;
	}

	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public String getCourse_img_path() {
		return course_img_path;
	}

	public void setCourse_img_path(String course_img_path) {
		this.course_img_path = course_img_path;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	public CourseDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

}
