package com.sarada.rasik.bhita.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "about_us")
public class Aboutus {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	public int story_id;

	public int page_id;

	public String description;

	public String story_heading;

	public String story;

	public String story_img;

	public Date created_date;

	public int created_by;

	public Date update_date;

	public int update_by;

	public Aboutus(int page_id, int story_id, String description, String story_heading, String story, String story_img,
			Date created_date, int created_by, Date update_date, int update_by, List<Aboutus> aboutus) {
		super();
		this.page_id = page_id;
		this.story_id = story_id;
		this.description = description;
		this.story_heading = story_heading;
		this.story = story;
		this.story_img = story_img;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}

	public Aboutus() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPage_id() {
		return page_id;
	}

	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}

	public int getStory_id() {
		return story_id;
	}

	public void setStory_id(int story_id) {
		this.story_id = story_id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStory_heading() {
		return story_heading;
	}

	public void setStory_heading(String story_heading) {
		this.story_heading = story_heading;
	}

	public String getStory() {
		return story;
	}

	public void setStory(String story) {
		this.story = story;
	}

	public String getStory_img() {
		return story_img;
	}

	public void setStory_img(String story_img) {
		this.story_img = story_img;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	@Override
	public String toString() {
		return "about_us [page_id=" + page_id + ", story_id=" + story_id + ", description=" + description
				+ ", story_heading=" + story_heading + ", story=" + story + ", story_img=" + story_img
				+ ", created_date=" + created_date + ", created_by=" + created_by + ", update_date=" + update_date
				+ ", update_by=" + update_by + "]";
	}

}
