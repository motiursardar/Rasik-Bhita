
package com.sarada.rasik.bhita.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.sarada.rasik.bhita.entity.AdvisoryCommittee;
import com.sarada.rasik.bhita.entity.AllCourseFee;
import com.sarada.rasik.bhita.entity.ContactDakshineswar;
import com.sarada.rasik.bhita.entity.CourseDetails;
import com.sarada.rasik.bhita.entity.CourseGroup;
import com.sarada.rasik.bhita.entity.Courses;
import com.sarada.rasik.bhita.entity.CoursesFees;
import com.sarada.rasik.bhita.entity.Homecarousoullmage;
import com.sarada.rasik.bhita.entity.MasterManu;
import com.sarada.rasik.bhita.entity.OurOrigin;
import com.sarada.rasik.bhita.entity.Pages;
import com.sarada.rasik.bhita.entity.Premises;
import com.sarada.rasik.bhita.entity.StoryOfRasik;
import com.sarada.rasik.bhita.repository.AdvisoryCommitteeRepo;
import com.sarada.rasik.bhita.repository.BhitaRepo;
import com.sarada.rasik.bhita.repository.Contact_Repo;
import com.sarada.rasik.bhita.repository.CoursesFeesRepo;
import com.sarada.rasik.bhita.repository.CoursesRepo;
import com.sarada.rasik.bhita.repository.ImgStoryRepo;
import com.sarada.rasik.bhita.repository.MasterManuRepo;
import com.sarada.rasik.bhita.repository.OurOriginRepo;
import com.sarada.rasik.bhita.repository.PremisesRepo;

//@ComponentScan
//MULTIPLE ENTITY WITH ID
@Service
public class RasikBhitaServiceImpl implements RasikBhitaService {

	@Autowired
	private BhitaRepo bhitaRepo;///Contact_Repo

	@Autowired
//	private ImgStoryRepo imgStoryRepo;
	private MasterManuRepo masterManuRepo;
	@Autowired 
	private Contact_Repo contact_Repo;
	public Optional<Pages> gethomePageData(int page_id) {
		Optional<Pages> allHomePageData = null;
		try {
			allHomePageData = bhitaRepo.findById(page_id);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return allHomePageData;
	}

	@Override
	public List<Pages> homecarousal() {

		return null;
	}

	@Override
	public List<Homecarousoullmage> getAll() {

		return null;
	}

	/////////////////////////////////////////////////////////
	@Autowired
	private CoursesFeesRepo coursesFeesRepo;

	public List<CoursesFees> findEntitiesWithJoin() {
		List<CoursesFees> coursesFeesob = null;
		try {
			coursesFeesob = coursesFeesRepo.findEntitiesWithJoin();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return coursesFeesob;
	}

	@Override
	public List<CoursesFees> CoursesFees() {

		return null;
	}

	//////////////////////////////////////////////////////
	@Autowired
	private CoursesRepo coursesRepo;

	public List<Courses> findAll() {
		List<Courses> courseListOb = null;
		try {
			courseListOb = coursesRepo.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return courseListOb;
	}

	public List<Courses> getAllcourses() {

		return null;
	}

	@Override
	public List<Courses> courseListOb() {

		return null;
	}

	//////////////////////////////////////////////////////

	public List<CourseDetails> FinndCourseDetailsByCourseId(int course_id) {
		List<CourseDetails> courseListOb = null;
		try {
			courseListOb = coursesRepo.FinndCourseDetailsByCourseId(course_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return courseListOb;
	}

	@Override
	public List<CourseDetails> FinndCourseDetailsByCourseId() {

		return null;
	}

	/////////////////////////////////////////////////////////////////

	public List<CoursesFees> FinndCourseFeesByCourseId(int course_id) {
		List<CoursesFees> courseListOb = null;
		try {
			courseListOb = coursesFeesRepo.FinndCourseFeesByCourseId(course_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return courseListOb;
	}

	@Override
	public List<CoursesFees> FinndCourseFeesByCourseId() {

		return null;
	}

	/////////////////////////////////////////

	public List<CourseGroup> getAllcourseGroup() {
		List<CourseGroup> courseListOb = null;
		try {
			courseListOb = coursesRepo.findAllGroup();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return courseListOb;
	}

//////////////////////////////////////////////////////////
	@Autowired
	private ImgStoryRepo imgStoryRepo;

	public List<StoryOfRasik> findStory() {
		List<StoryOfRasik> storyListOb = null;
		try {
			storyListOb = imgStoryRepo.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return storyListOb;
	}

	@Override
	public List<StoryOfRasik> FinndStoryOfRasik() {
		// TODO Auto-generated method stub
		return null;
	}

	//////////////////////////////////////////////////

	@Autowired
	private PremisesRepo premisesRepo;

	public List<Premises> getAllPremises() {
		List<Premises> PremisesListOb = null;
		try {
			PremisesListOb = premisesRepo.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return PremisesListOb;
	}

	@Override
	public List<Premises> FinndPremisesOfRasik() {
		// TODO Auto-generated method stub
		return null;
	}
	//////////////////////////////////////////////////////////
//	@Autowired
//	private OurOriginRepo ourOriginRepo;
//
//	public List<OurOrigin> getAllOurOrigin() {
//		List<OurOrigin> OurOriginListOb = null;
//		try {
//			OurOriginListOb = ourOriginRepo.findAll();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return OurOriginListOb;
//		}
//	@Override
//	public List<OurOrigin> FinndOurOrigin() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	/////////////////////////////////////////////////////////////
//	
//	@Autowired
//	private AdvisoryCommitteeRepo advisoryCommitteeRepo;
//
//	public List<AdvisoryCommittee> getAllCommittee() {
//		List<AdvisoryCommittee> AdvisoryCommitteeListOb = null;
//		try {
//			AdvisoryCommitteeListOb = advisoryCommitteeRepo.findAll();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return AdvisoryCommitteeListOb;
//		}
//	@Override
//	public List<AdvisoryCommittee> FinndOurCommittee() {
//		// TODO Auto-generated method stub
//		return null;
//	}
	///////////////////////////////////////////////
////	@Override
//	public  AdvisoryCommittee save(AdvisoryCommittee advisoryCommittee) {
//		
//		AdvisoryCommittee saveData = advisoryCommitteeRepo.save(advisoryCommittee);
//		return saveData;
//		
//		
//	}
//
//	@Override
//	public AdvisoryCommittee saveData(AdvisoryCommittee advisoryCommittee) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	////////////////////////////////////////////////////////////////////
//	@Autowired
//	private PremisesRepo premisesRepo;

//	public List<AllCourseFee> getAllAllCourseFee() {
//		List<AllCourseFee> AllCourseFeeListOb = null;
//		try {
//			AllCourseFeeListOb = premisesRepo.findAllAllCourseFee();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return AllCourseFeeListOb;
//	}
//
//	@Override
//	public List<AllCourseFee> FinndAllCourseFee() {
//		// TODO Auto-generated method stub
//		return null;
//	}

	///////////////////////////////////////////
	public List<AllCourseFee> FinndAllCourseFee() {
		List<AllCourseFee> AllCourseFeeOb = null;
		try {
			AllCourseFeeOb = premisesRepo.FinndAllCourseFee();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return AllCourseFeeOb;
	}

	@Override
	public List<AllCourseFee> FinndCourseFee() {

		return null;
	}
	///////////////////////////////////////////////////////////////

/////////////////////////////////////////
	//DEVELOP Motiur Help by Bharat da @OneToMany
	
	
	public List<MasterManu> getmastermanuAndSubData(int menu_id) {
		List<MasterManu> allMasterManuData =null;

		try {
			allMasterManuData = masterManuRepo.getBymenu(menu_id);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return allMasterManuData;
	}

	@Override
	public List<MasterManu> masterMenudata() {

		return null;
	}
////////////////////////////////////////////////////////////////////
	
	public List<ContactDakshineswar> getContactDakshineswar(Integer contactid) {
		List<ContactDakshineswar> contactDakshineswarob =null;

		try {
			contactDakshineswarob = contact_Repo.findAllById(contactid);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return contactDakshineswarob;
	}

	@Override
	public List<ContactDakshineswar> contactDakshineswar() {
	

		return null;
	}

}
