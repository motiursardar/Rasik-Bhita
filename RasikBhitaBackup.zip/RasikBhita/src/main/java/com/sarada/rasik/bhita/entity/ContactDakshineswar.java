package com.sarada.rasik.bhita.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "contactDakshineswar")
public class ContactDakshineswar {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	public int contactid;
	public String office_Location;
	public String contact_Number;
	public String official_Emailaddress;
	public String contacthedimg;
	public String admission_Course_Related_Queries;
	public String visitinghours;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "contactid", insertable = false)
	public List<ContactDumdumPark> ContactDumdumParkList;

	public int getContactid() {
		return contactid;
	}

	public void setContactid(int contactid) {
		this.contactid = contactid;
	}

	public String getOffice_Location() {
		return office_Location;
	}

	public void setOffice_Location(String office_Location) {
		this.office_Location = office_Location;
	}

	public String getContact_Number() {
		return contact_Number;
	}

	public void setContact_Number(String contact_Number) {
		this.contact_Number = contact_Number;
	}

	public String getOfficial_Emailaddress() {
		return official_Emailaddress;
	}

	public void setOfficial_Emailaddress(String official_Emailaddress) {
		this.official_Emailaddress = official_Emailaddress;
	}

	public String getContacthedimg() {
		return contacthedimg;
	}

	public void setContacthedimg(String contacthedimg) {
		this.contacthedimg = contacthedimg;
	}

	public String getAdmission_Course_Related_Queries() {
		return admission_Course_Related_Queries;
	}

	public void setAdmission_Course_Related_Queries(String admission_Course_Related_Queries) {
		this.admission_Course_Related_Queries = admission_Course_Related_Queries;
	}

	public String getVisitinghours() {
		return visitinghours;
	}

	public void setVisitinghours(String visitinghours) {
		this.visitinghours = visitinghours;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	public ContactDakshineswar(int contactid, String office_Location, String contact_Number,
			String official_Emailaddress, String contacthedimg, String admission_Course_Related_Queries,
			String visitinghours, Date created_date, int created_by, Date update_date, int update_by) {
		this.contactid = contactid;
		this.office_Location = office_Location;
		this.contact_Number = contact_Number;
		this.official_Emailaddress = official_Emailaddress;
		this.contacthedimg = contacthedimg;
		this.admission_Course_Related_Queries = admission_Course_Related_Queries;
		this.visitinghours = visitinghours;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}

	public ContactDakshineswar() {
		super();
		// TODO Auto-generated constructor stub
	}

}
