package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RasikBhitaContactUs")
public class ContactUs {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	public int contactid;
	public String small_heading;
	public String big_Heading;
	public String description;
	public String text_Area;
	public Date place_Nam;
	public String office_Locatio;
	public String contact_No;
	public String email;
	public String queries;
	public String visiting_hour;
	public String google_Map_Url;
	public Date create_date;
	public Date update_date;
	public int update_by;
	public int create_by;
	
	public int getContactid() {
		return contactid;
	}
	public void setContactid(int contactid) {
		this.contactid = contactid;
	}
	public String getSmall_heading() {
		return small_heading;
	}
	public void setSmall_heading(String small_heading) {
		this.small_heading = small_heading;
	}
	public String getBig_Heading() {
		return big_Heading;
	}
	public void setBig_Heading(String big_Heading) {
		this.big_Heading = big_Heading;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getText_Area() {
		return text_Area;
	}
	public void setText_Area(String text_Area) {
		this.text_Area = text_Area;
	}
	public Date getPlace_Nam() {
		return place_Nam;
	}
	public void setPlace_Nam(Date place_Nam) {
		this.place_Nam = place_Nam;
	}
	public String getOffice_Locatio() {
		return office_Locatio;
	}
	public void setOffice_Locatio(String office_Locatio) {
		this.office_Locatio = office_Locatio;
	}
	public String getContact_No() {
		return contact_No;
	}
	public void setContact_No(String contact_No) {
		this.contact_No = contact_No;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getQueries() {
		return queries;
	}
	public void setQueries(String queries) {
		this.queries = queries;
	}
	public String getVisiting_hour() {
		return visiting_hour;
	}
	public void setVisiting_hour(String visiting_hour) {
		this.visiting_hour = visiting_hour;
	}
	public String getGoogle_Map_Url() {
		return google_Map_Url;
	}
	public void setGoogle_Map_Url(String google_Map_Url) {
		this.google_Map_Url = google_Map_Url;
	}
	public Date getCreate_date() {
		return create_date;
	}
	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public int getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	public int getCreate_by() {
		return create_by;
	}
	public void setCreate_by(int create_by) {
		this.create_by = create_by;
	}
	public ContactUs(int contactid, String small_heading, String big_Heading, String description, String text_Area,
			Date place_Nam, String office_Locatio, String contact_No, String email, String queries,
			String visiting_hour, String google_Map_Url, Date create_date, Date update_date, int update_by,
			int create_by) {
		this.contactid = contactid;
		this.small_heading = small_heading;
		this.big_Heading = big_Heading;
		this.description = description;
		this.text_Area = text_Area;
		this.place_Nam = place_Nam;
		this.office_Locatio = office_Locatio;
		this.contact_No = contact_No;
		this.email = email;
		this.queries = queries;
		this.visiting_hour = visiting_hour;
		this.google_Map_Url = google_Map_Url;
		this.create_date = create_date;
		this.update_date = update_date;
		this.update_by = update_by;
		this.create_by = create_by;
	}
	public ContactUs() {
		super();
		
	}
	
	

}
