package com.sarada.rasik.bhita.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.sarada.rasik.bhita.entity.AdvisoryCommittee;


public interface AdvisoryCommitteeRepo extends JpaRepository < AdvisoryCommittee, Integer>{

	

	

}
