package com.sarada.rasik.bhita.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sarada.rasik.bhita.entity.CoursesFees;

public interface CoursesFeesRepo extends JpaRepository<CoursesFees, Integer> {

	@Query("SELECT new com.sarada.rasik.bhita.entity.CoursesFees" + "(c1.fees_id as fees_id, "
			+ "c1.course_id as course_id, " + "c2.course_name as course_name, " + "c2.duration as duration, "
			+ "c1.total_course_fees as total_course_fees," + "\r\n" + "	c1.admission_fees as admission_fees,"
			+ " c1.fees_to_installments as fees_to_installments," + " c1.create_by as create_by, "
			+ "c1.create_date as create_date, " + "c1.update_by as update_by,\r\n" + "	c1.update_date as update_date) "
			+ "FROM CoursesFees as c1 Join CourseDetails as c2 ON c1.course_id = c2.course_id")
	List<CoursesFees> findEntitiesWithJoin();

	// @Query("Select cF From CoursesFees cF WHERE cF.course_id=:course_id")

	@Query("SELECT new com.sarada.rasik.bhita.entity.CoursesFees" + "(c1.fees_id as fees_id,"
			+ "c1.course_id as course_id," + "c2.course_name as course_name," + "c2.duration as duration, "
			+ "c1.total_course_fees as total_course_fees,\r\n" + "c1.admission_fees as admission_fees,"
			+ "c1.fees_to_installments as fees_to_installments, " + "c1.create_by as create_by, "
			+ "c1.create_date as create_date, " + "c1.update_by as update_by,\r\n" + "c1.update_date as update_date) "
			+ "FROM CoursesFees as c1 Join CourseDetails as c2 ON c1.course_id = c2.course_id WHERE c1.course_id=:course_id")
	List<CoursesFees> FinndCourseFeesByCourseId(@Param("course_id") int course_id);
/////////////////////////////////////////

}
