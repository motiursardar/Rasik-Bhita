package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "premises")
public class Premises {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int premises_id;

	public String premises_h_img_path;

	public String premises_b_img_path;

	public String premises_text;

	public Date created_date;
	public int created_by;

	public Date update_date;
	public int update_by;

	public int getPremises_id() {
		return premises_id;
	}

	public void setPremises_id(int premises_id) {
		this.premises_id = premises_id;
	}

	public String getPremises_h_img_path() {
		return premises_h_img_path;
	}

	public void setPremises_h_img_path(String premises_h_img_path) {
		this.premises_h_img_path = premises_h_img_path;
	}

	public String getPremises_b_img_path() {
		return premises_b_img_path;
	}

	public void setPremises_b_img_path(String premises_b_img_path) {
		this.premises_b_img_path = premises_b_img_path;
	}

	public String getPremises_text() {
		return premises_text;
	}

	public void setPremises_text(String premises_text) {
		this.premises_text = premises_text;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	public Premises(int premises_id, String premises_h_img_path, String premises_b_img_path, String premises_text,
			Date created_date, int created_by, Date update_date, int update_by) {
		this.premises_id = premises_id;
		this.premises_h_img_path = premises_h_img_path;
		this.premises_b_img_path = premises_b_img_path;
		this.premises_text = premises_text;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}

	public Premises() {
		super();
		// TODO Auto-generated constructor stub
	}

}
