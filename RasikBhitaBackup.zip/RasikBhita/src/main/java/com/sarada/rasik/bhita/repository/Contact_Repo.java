package com.sarada.rasik.bhita.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sarada.rasik.bhita.entity.ContactDakshineswar;
import com.sarada.rasik.bhita.entity.ContactDumdumPark;


public interface Contact_Repo extends JpaRepository<ContactDakshineswar, Integer> {

	@Query("Select  distinct cd From ContactDakshineswar as cd WHERE cd.contactid=:contactid")
	
	List<ContactDakshineswar> findAllById(@Param("contactid")int contactid);
	void save(ContactDumdumPark contactDumdumPark);
}
