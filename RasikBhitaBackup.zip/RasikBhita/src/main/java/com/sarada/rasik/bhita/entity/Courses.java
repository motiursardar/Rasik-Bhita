package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "courses")
public class Courses {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int course_id;
	@Column(name = "course_group_id")
	public int group_id;
	public int page_id;
	public String course_name;
	public String course_short_desc;
	public String course_desc;
	public String course_icon;
	private int course_active;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;

	public Courses() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public int getPage_id() {
		return page_id;
	}

	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public String getCourse_short_desc() {
		return course_short_desc;
	}

	public void setCourse_short_desc(String course_short_desc) {
		this.course_short_desc = course_short_desc;
	}

	public String getCourse_desc() {
		return course_desc;
	}

	public void setCourse_desc(String course_desc) {
		this.course_desc = course_desc;
	}

	public String getCourse_icon() {
		return course_icon;
	}

	public void setCourse_icon(String course_icon) {
		this.course_icon = course_icon;
	}

	public int getCourse_active() {
		return course_active;
	}

	public void setCourse_active(int course_active) {
		this.course_active = course_active;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	

	public int getGroup_id() {
		return group_id;
	}

	public void setGroup_id(int group_id) {
		this.group_id = group_id;
	}

	public Courses(int course_id, int page_id, String course_name, String course_short_desc, String course_desc,
			String course_icon, int course_active, Date created_date, int created_by, Date update_date, int update_by) {
		this.course_id = course_id;
		this.page_id = page_id;
		this.course_name = course_name;
		this.course_short_desc = course_short_desc;
		this.course_desc = course_desc;
		this.course_icon = course_icon;
		this.course_active = course_active;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}

}
