package com.sarada.rasik.bhita.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sarada.rasik.bhita.entity.CourseDetails;
import com.sarada.rasik.bhita.entity.CourseGroup;
import com.sarada.rasik.bhita.entity.Courses;

public interface CoursesRepo extends JpaRepository<Courses, Integer> {

	@Query("Select cd From CourseDetails cd WHERE cd.course_id=:course_id")
	public List<CourseDetails> FinndCourseDetailsByCourseId(@Param("course_id") int course_id);

	@Query("Select cg From CourseGroup cg WHERE cg.group_active=1")
	public List<CourseGroup> findAllGroup();

/////////////////////////////////////////////////////////

}
