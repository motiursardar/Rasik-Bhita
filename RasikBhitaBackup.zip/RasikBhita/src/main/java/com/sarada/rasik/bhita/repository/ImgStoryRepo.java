package com.sarada.rasik.bhita.repository;





import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sarada.rasik.bhita.entity.StoryOfRasik;

public interface ImgStoryRepo extends JpaRepository<StoryOfRasik, Integer>{

	@Query("Select sr From StoryOfRasik sr")
	List<StoryOfRasik> FinndStoryOfRasik();

	

}
