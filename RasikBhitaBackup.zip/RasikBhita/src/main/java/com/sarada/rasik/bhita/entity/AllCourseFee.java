package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "all_course_fees")

public class AllCourseFee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int course_id;
	public String course_name;
	public String course_duration;
	public int total_course_fee;
	public int admission_fees;
	public String fees_in_installments;
	public Date update_by_date;
	public Date create_by_date;
	public int update_by_id;
	public int create_by_id;

	public AllCourseFee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public String getCourse_duration() {
		return course_duration;
	}

	public void setCourse_duration(String course_duration) {
		this.course_duration = course_duration;
	}

	public int getTotal_course_fee() {
		return total_course_fee;
	}

	public void setTotal_course_fee(int total_course_fee) {
		this.total_course_fee = total_course_fee;
	}

	public int getAdmission_fees() {
		return admission_fees;
	}

	public void setAdmission_fees(int admission_fees) {
		this.admission_fees = admission_fees;
	}

	public String getFees_in_installments() {
		return fees_in_installments;
	}

	public void setFees_in_installments(String fees_in_installments) {
		this.fees_in_installments = fees_in_installments;
	}

	public Date getUpdate_by_date() {
		return update_by_date;
	}

	public void setUpdate_by_date(Date update_by_date) {
		this.update_by_date = update_by_date;
	}

	public Date getCreate_by_date() {
		return create_by_date;
	}

	public void setCreate_by_date(Date create_by_date) {
		this.create_by_date = create_by_date;
	}

	public int getUpdate_by_id() {
		return update_by_id;
	}

	public void setUpdate_by_id(int update_by_id) {
		this.update_by_id = update_by_id;
	}

	public int getCreate_by_id() {
		return create_by_id;
	}

	public void setCreate_by_id(int create_by_id) {
		this.create_by_id = create_by_id;
	}

	public AllCourseFee(int course_id, String course_name, String course_duration, int total_course_fee,
			int admission_fees, String fees_in_installments, Date update_by_date, Date create_by_date, int update_by_id,
			int create_by_id) {
		this.course_id = course_id;
		this.course_name = course_name;
		this.course_duration = course_duration;
		this.total_course_fee = total_course_fee;
		this.admission_fees = admission_fees;
		this.fees_in_installments = fees_in_installments;
		this.update_by_date = update_by_date;
		this.create_by_date = create_by_date;
		this.update_by_id = update_by_id;
		this.create_by_id = create_by_id;
	}

}
