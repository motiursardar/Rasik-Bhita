package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sub_menu")
public class SubMenu {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

//public class MasterManu {
	public int id;
	@Column(name = "menu_id")
	public int menu_id;
	public String sub_aboutus;
	public String sub_courses;
	public String sub_activities;
	public String sub_gallery;
	public String sub_news;
	public String sub_contactus;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMenu_id() {
		return menu_id;
	}
	public void setMenu_id(int menu_id) {
		this.menu_id = menu_id;
	}
	public String getSub_aboutus() {
		return sub_aboutus;
	}
	public void setSub_aboutus(String sub_aboutus) {
		this.sub_aboutus = sub_aboutus;
	}
	public String getSub_courses() {
		return sub_courses;
	}
	public void setSub_courses(String sub_courses) {
		this.sub_courses = sub_courses;
	}
	public String getSub_activities() {
		return sub_activities;
	}
	public void setSub_activities(String sub_activities) {
		this.sub_activities = sub_activities;
	}
	public String getSub_gallery() {
		return sub_gallery;
	}
	public void setSub_gallery(String sub_gallery) {
		this.sub_gallery = sub_gallery;
	}
	public String getSub_news() {
		return sub_news;
	}
	public void setSub_news(String sub_news) {
		this.sub_news = sub_news;
	}
	public String getSub_contactus() {
		return sub_contactus;
	}
	public void setSub_contactus(String sub_contactus) {
		this.sub_contactus = sub_contactus;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getCreated_by() {
		return created_by;
	}
	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public int getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	public SubMenu(int id, int menu_id, String sub_aboutus, String sub_courses, String sub_activities,
			String sub_gallery, String sub_news, String sub_contactus, Date created_date, int created_by,
			Date update_date, int update_by) {
		this.id = id;
		this.menu_id = menu_id;
		this.sub_aboutus = sub_aboutus;
		this.sub_courses = sub_courses;
		this.sub_activities = sub_activities;
		this.sub_gallery = sub_gallery;
		this.sub_news = sub_news;
		this.sub_contactus = sub_contactus;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}
	public SubMenu() {
		super();
		// TODO Auto-generated constructor stub
	}

}