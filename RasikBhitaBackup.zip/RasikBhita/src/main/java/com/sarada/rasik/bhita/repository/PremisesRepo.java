package com.sarada.rasik.bhita.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.sarada.rasik.bhita.entity.AllCourseFee;
import com.sarada.rasik.bhita.entity.Premises;

public interface PremisesRepo extends JpaRepository<Premises, Integer> {



	static Optional<Premises> findById(long premises_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Query("SELECT A FROM AllCourseFee A")

	public List<AllCourseFee> FinndAllCourseFee();

}
