package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import javax.persistence.Table;

@Entity
@Table(name = "student_project")
public class StudentProject {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	public int project_id;
	public int page_id;
	public String project_name;
	public String project_img;
	public int prject_visible;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;

	public StudentProject(int page_id, int project_id, String project_name, String project_img, int prject_visible,
			Date created_date, int created_by, Date update_date, int update_by) {
		super();
		this.page_id = page_id;
		this.project_id = project_id;
		this.project_name = project_name;
		this.project_img = project_img;
		this.prject_visible = prject_visible;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}
	
	

	public StudentProject() {
		super();
		// TODO Auto-generated constructor stub
	}



	public int getPage_id() {
		return page_id;
	}

	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}

	public int getProject_id() {
		return project_id;
	}

	public void setProject_id(int project_id) {
		this.project_id = project_id;
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

	public String getProject_img() {
		return project_img;
	}

	public void setProject_img(String project_img) {
		this.project_img = project_img;
	}

	public int getPrject_visible() {
		return prject_visible;
	}

	public void setPrject_visible(int prject_visible) {
		this.prject_visible = prject_visible;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	@Override
	public String toString() {
		return "student_project [page_id=" + page_id + ", project_id=" + project_id + ", project_name=" + project_name
				+ ", project_img=" + project_img + ", prject_visible=" + prject_visible + ", created_date="
				+ created_date + ", created_by=" + created_by + ", update_date=" + update_date + ", update_by="
				+ update_by + "]";
	}

}
