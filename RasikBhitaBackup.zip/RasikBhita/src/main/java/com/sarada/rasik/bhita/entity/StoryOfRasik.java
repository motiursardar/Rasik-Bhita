package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "story_of_rasik")

public class StoryOfRasik {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int Story_cms_id;
	@Column(name = "cms_heading_img_path")

	public String cms_heading_img_path;

	@Column(name = "cms_body_img_path")

	public String cms_body_img_path;

	@Column(name = "cms_text")

	public String cms_text;

	@Column(name = "created_date")
	public Date created_date;

	@Column(name = "created_by")
	public int created_by;

	@Column(name = "update_date")
	public Date update_date;

	@Column(name = "update_by")
	public int update_by;

	public StoryOfRasik() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getStory_cms_id() {
		return Story_cms_id;
	}

	public void setStory_cms_id(int story_cms_id) {
		Story_cms_id = story_cms_id;
	}

	public String getCms_heading_img_path() {
		return cms_heading_img_path;
	}

	public void setCms_heading_img_path(String cms_heading_img_path) {
		this.cms_heading_img_path = cms_heading_img_path;
	}

	public String getCms_body_img_path() {
		return cms_body_img_path;
	}

	public void setCms_body_img_path(String cms_body_img_path) {
		this.cms_body_img_path = cms_body_img_path;
	}

	public String getCms_text() {
		return cms_text;
	}

	public void setCms_text(String cms_text) {
		this.cms_text = cms_text;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	public StoryOfRasik(int story_cms_id, String cms_heading_img_path, String cms_body_img_path, String cms_text,
			Date created_date, int created_by, Date update_date, int update_by) {
		Story_cms_id = story_cms_id;
		this.cms_heading_img_path = cms_heading_img_path;
		this.cms_body_img_path = cms_body_img_path;
		this.cms_text = cms_text;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}

	@Override
	public String toString() {
		return "StoryOfRasik [Story_cms_id=" + Story_cms_id + ", cms_heading_img_path=" + cms_heading_img_path
				+ ", cms_body_img_path=" + cms_body_img_path + ", cms_text=" + cms_text + ", created_date="
				+ created_date + ", created_by=" + created_by + ", update_date=" + update_date + ", update_by="
				+ update_by + "]";
	}

}
