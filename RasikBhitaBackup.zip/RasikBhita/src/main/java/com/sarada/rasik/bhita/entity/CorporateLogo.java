package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "corporate_logo")
public class CorporateLogo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 
	public int logo_id;
	public int page_id;
	public String logo_path;
	public int logo_visible;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;
	public CorporateLogo(int page_id, int logo_id, String logo_path, int logo_visible, Date created_date,
			int created_by, Date update_date, int update_by) {
		super();
		this.page_id = page_id;
		this.logo_id = logo_id;
		this.logo_path = logo_path;
		this.logo_visible = logo_visible;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}
	
	public CorporateLogo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPage_id() {
		return page_id;
	}
	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}
	public int getLogo_id() {
		return logo_id;
	}
	public void setLogo_id(int logo_id) {
		this.logo_id = logo_id;
	}
	public String getLogo_path() {
		return logo_path;
	}
	public void setLogo_path(String logo_path) {
		this.logo_path = logo_path;
	}
	public int getLogo_visible() {
		return logo_visible;
	}
	public void setLogo_visible(int logo_visible) {
		this.logo_visible = logo_visible;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getCreated_by() {
		return created_by;
	}
	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public int getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	@Override
	public String toString() {
		return "corporate_logo [page_id=" + page_id + ", logo_id=" + logo_id + ", logo_path=" + logo_path
				+ ", logo_visible=" + logo_visible + ", created_date=" + created_date + ", created_by=" + created_by
				+ ", update_date=" + update_date + ", update_by=" + update_by + "]";
	}
	
	

}
