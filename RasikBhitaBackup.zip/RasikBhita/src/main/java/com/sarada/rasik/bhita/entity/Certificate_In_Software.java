package com.sarada.rasik.bhita.entity;

import java.util.Date;

public class Certificate_In_Software {
	
	
	public int course_id;
	public String course_name;
	public int duration_of_course;
	public String course_content;
	public String job_roles;
	public String head_img;
	public String body_img;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;

}
