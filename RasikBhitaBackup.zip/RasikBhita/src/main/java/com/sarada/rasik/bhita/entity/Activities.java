package com.sarada.rasik.bhita.entity;

import java.util.Date;


import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "activities")
public class Activities {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	public int actvity_id;
	public int page_id;
	public String actvity_headings;
	public String actvity_body;
	public String actvity_img;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;

	public Activities(int page_id, int actvity_id, String actvity_headings, String actvity_body, String actvity_img,
			Date created_date, int created_by, Date update_date, int update_by) {
		super();
		this.page_id = page_id;
		this.actvity_id = actvity_id;
		this.actvity_headings = actvity_headings;
		this.actvity_body = actvity_body;
		this.actvity_img = actvity_img;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}

	public Activities() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPage_id() {
		return page_id;
	}

	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}

	public int getActvity_id() {
		return actvity_id;
	}

	public void setActvity_id(int actvity_id) {
		this.actvity_id = actvity_id;
	}

	public String getActvity_headings() {
		return actvity_headings;
	}

	public void setActvity_headings(String actvity_headings) {
		this.actvity_headings = actvity_headings;
	}

	public String getActvity_body() {
		return actvity_body;
	}

	public void setActvity_body(String actvity_body) {
		this.actvity_body = actvity_body;
	}

	public String getActvity_img() {
		return actvity_img;
	}

	public void setActvity_img(String actvity_img) {
		this.actvity_img = actvity_img;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	@Override
	public String toString() {
		return "activities [page_id=" + page_id + ", actvity_id=" + actvity_id + ", actvity_headings="
				+ actvity_headings + ", actvity_body=" + actvity_body + ", actvity_img=" + actvity_img
				+ ", created_date=" + created_date + ", created_by=" + created_by + ", update_date=" + update_date
				+ ", update_by=" + update_by + "]";
	}

}
