package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "corporate_connect")
public class CorporateConnect {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	public int id;
	public int page_id;
	public String description;
	public String corporate_head;
	public String corporate_body;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;

	public CorporateConnect(int page_id, int id, String description, String corporate_head, String corporate_body,
			Date created_date, int created_by, Date update_date, int update_by) {
		super();
		this.page_id = page_id;
		this.id = id;
		this.description = description;
		this.corporate_head = corporate_head;
		this.corporate_body = corporate_body;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}

	
	public CorporateConnect() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getPage_id() {
		return page_id;
	}

	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCorporate_head() {
		return corporate_head;
	}

	public void setCorporate_head(String corporate_head) {
		this.corporate_head = corporate_head;
	}

	public String getCorporate_body() {
		return corporate_body;
	}

	public void setCorporate_body(String corporate_body) {
		this.corporate_body = corporate_body;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	@Override
	public String toString() {
		return "corporate_connect [page_id=" + page_id + ", id=" + id + ", description=" + description
				+ ", corporate_head=" + corporate_head + ", corporate_body=" + corporate_body + ", created_date="
				+ created_date + ", created_by=" + created_by + ", update_date=" + update_date + ", update_by="
				+ update_by + "]";
	}

}
