package com.sarada.rasik.bhita.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "student_words")
public class StudentWords {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	public int word_id;
	public int page_id;
	public String student_name;
	public String student_img;
	public String designation;
	public int words_active;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;
	public String message;

	public StudentWords(int word_id, int page_id, String student_name, String student_img, String designation,
			int words_active, Date created_date, int created_by, Date update_date, int update_by, String message) {
		super();
		this.word_id = word_id;
		this.page_id = page_id;
		this.student_name = student_name;
		this.student_img = student_img;
		this.designation = designation;
		this.words_active = words_active;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
		this.message = message;
	}

	public StudentWords() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getWord_id() {
		return word_id;
	}

	public void setWord_id(int word_id) {
		this.word_id = word_id;
	}

	public int getpage_id() {
		return page_id;
	}

	public void setpage_id(int page_id) {
		this.page_id = page_id;
	}

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public String getStudent_img() {
		return student_img;
	}

	public void setStudent_img(String student_img) {
		this.student_img = student_img;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getWords_active() {
		return words_active;
	}

	public void setWords_active(int words_active) {
		this.words_active = words_active;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "StudentWords [word_id=" + word_id + ", page_id=" + page_id + ", student_name=" + student_name
				+ ", student_img=" + student_img + ", designation=" + designation + ", words_active=" + words_active
				+ ", created_date=" + created_date + ", created_by=" + created_by + ", update_date=" + update_date
				+ ", update_by=" + update_by + ", message=" + message + "]";
	}

}
