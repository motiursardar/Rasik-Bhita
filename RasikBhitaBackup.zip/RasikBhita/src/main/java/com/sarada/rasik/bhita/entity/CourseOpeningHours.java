package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Course_opening_hours")

public class CourseOpeningHours {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 
	public int Course_opening_hours_id;
	public int page_id;
	public int course_id;
	public String day_name;
	public String timing;
	public int course_open;
	public Date created_date;
	public int created_by;
	public Date update_date;
	public int update_by;
	public CourseOpeningHours(int page_id, int course_opening_hours_id, int course_id, String day_name, String timing,
			int course_open, Date created_date, int created_by, Date update_date, int update_by) {
		super();
		this.page_id = page_id;
		Course_opening_hours_id = course_opening_hours_id;
		this.course_id = course_id;
		this.day_name = day_name;
		this.timing = timing;
		this.course_open = course_open;
		this.created_date = created_date;
		this.created_by = created_by;
		this.update_date = update_date;
		this.update_by = update_by;
	}
	
	public CourseOpeningHours() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPage_id() {
		return page_id;
	}
	public void setPage_id(int page_id) {
		this.page_id = page_id;
	}
	public int getCourse_opening_hours_id() {
		return Course_opening_hours_id;
	}
	public void setCourse_opening_hours_id(int course_opening_hours_id) {
		Course_opening_hours_id = course_opening_hours_id;
	}
	public int getCourse_id() {
		return course_id;
	}
	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}
	public String getDay_name() {
		return day_name;
	}
	public void setDay_name(String day_name) {
		this.day_name = day_name;
	}
	public String getTiming() {
		return timing;
	}
	public void setTiming(String timing) {
		this.timing = timing;
	}
	public int getCourse_open() {
		return course_open;
	}
	public void setCourse_open(int course_open) {
		this.course_open = course_open;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getCreated_by() {
		return created_by;
	}
	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public int getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	@Override
	public String toString() {
		return "Course_opening_hours [page_id=" + page_id + ", Course_opening_hours_id=" + Course_opening_hours_id
				+ ", course_id=" + course_id + ", day_name=" + day_name + ", timing=" + timing + ", course_open="
				+ course_open + ", created_date=" + created_date + ", created_by=" + created_by + ", update_date="
				+ update_date + ", update_by=" + update_by + "]";
	}
	
	
	

}
