package com.sarada.rasik.bhita.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "course_group")
public class CourseGroup {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int group_id;
	public String group_name;
	public String group_desc;
	public String group_active;
	public Date create_date;
	public int created_by;
	public Date update_date;
	public int updated_by;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "course_group_id", insertable = false)
	public List<Courses> coursesList;

	public List<Courses> getCoursesList() {
		return coursesList;
	}

	public void setCoursesList(List<Courses> coursesList) {
		this.coursesList = coursesList;
	}

	public int getGroup_id() {
		return group_id;
	}

	public void setGroup_id(int group_id) {
		this.group_id = group_id;
	}

	public String getGroup_name() {
		return group_name;
	}

	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}

	public String getGroup_desc() {
		return group_desc;
	}

	public void setGroup_desc(String group_desc) {
		this.group_desc = group_desc;
	}

	public int getCreated_by() {
		return created_by;
	}

	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public Date getCreate_date() {
		return create_date;
	}

	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}

	public int getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(int updated_by) {
		this.updated_by = updated_by;
	}

	public String getGroup_active() {
		return group_active;
	}

	public void setGroup_active(String group_active) {
		this.group_active = group_active;
	}

}
