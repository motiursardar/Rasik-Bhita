package com.sarada.rasik.bhita.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.sarada.rasik.bhita.entity.MasterManu;
import com.sarada.rasik.bhita.entity.SubMenu;

//DEVELOP Motiur Help by Bharat da @OneToMany
public interface MasterManuRepo extends JpaRepository<MasterManu, Integer> {

	

	////////////////////////////////////


	@Query("Select mm From MasterManu as mm WHERE mm.menu_id=:menu_id")

	List<MasterManu> getBymenu(@Param("menu_id") int menu_id);

	void save(SubMenu subMenuOb);

}
