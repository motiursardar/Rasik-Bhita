package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "courses_fees")
public class CoursesFees {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int course_id;
	public int fees_id;

	public String course_name;
	@Transient
	public int duration;

	public int total_course_fees;

	public int admission_fees;
	public String fees_to_installments;
	public int create_by;
	public Date create_date;
	public int update_by;
	public Date update_date;

	public int getFees_id() {
		return fees_id;
	}

	public void setFees_id(int fees_id) {
		this.fees_id = fees_id;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public String getCourse_name() {
		return course_name;
	}

	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getTotal_course_fees() {
		return total_course_fees;
	}

	public void setTotal_course_fees(int total_course_fees) {
		this.total_course_fees = total_course_fees;
	}

	public int getAdmission_fees() {
		return admission_fees;
	}

	public void setAdmission_fees(int admission_fees) {
		this.admission_fees = admission_fees;
	}

	public String getFees_to_installments() {
		return fees_to_installments;
	}

	public void setFees_to_installments(String fees_to_installments) {
		this.fees_to_installments = fees_to_installments;
	}

	public int getCreate_by() {
		return create_by;
	}

	public void setCreate_by(int create_by) {
		this.create_by = create_by;
	}

	public Date getCreate_date() {
		return create_date;
	}

	public void setCreate_date(Date create_date) {
		this.create_date = create_date;
	}

	public int getUpdate_by() {
		return update_by;
	}

	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}

	public Date getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}

	public CoursesFees() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CoursesFees(int fees_id, int course_id, String course_name, int duration, int total_course_fees,
			int admission_fees, String fees_to_installments, int create_by, Date create_date, int update_by,
			Date update_date) {
		this.fees_id = fees_id;
		this.course_id = course_id;
		this.course_name = course_name;
		this.duration = duration;
		this.total_course_fees = total_course_fees;
		this.admission_fees = admission_fees;
		this.fees_to_installments = fees_to_installments;
		this.create_by = create_by;
		this.create_date = create_date;
		this.update_by = update_by;
		this.update_date = update_date;
	}

}
