package com.sarada.rasik.bhita.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "our_origin")

public class OurOrigin {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int our_origin_id;
	public String our_origin_h_img_path;
	public String our_origin_b_img_path;
	public String origin_text;
	public int created_by;
	public Date created_date;
	public int update_by;
	public Date update_date;
	public OurOrigin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getOur_origin_id() {
		return our_origin_id;
	}
	public void setOur_origin_id(int our_origin_id) {
		this.our_origin_id = our_origin_id;
	}
	public String getOur_origin_h_img_path() {
		return our_origin_h_img_path;
	}
	public void setOur_origin_h_img_path(String our_origin_h_img_path) {
		this.our_origin_h_img_path = our_origin_h_img_path;
	}
	public String getOur_origin_b_img_path() {
		return our_origin_b_img_path;
	}
	public void setOur_origin_b_img_path(String our_origin_b_img_path) {
		this.our_origin_b_img_path = our_origin_b_img_path;
	}
	public String getOrigin_text() {
		return origin_text;
	}
	public void setOrigin_text(String origin_text) {
		this.origin_text = origin_text;
	}
	public int getCreated_by() {
		return created_by;
	}
	public void setCreated_by(int created_by) {
		this.created_by = created_by;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
	public int getUpdate_by() {
		return update_by;
	}
	public void setUpdate_by(int update_by) {
		this.update_by = update_by;
	}
	public Date getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(Date update_date) {
		this.update_date = update_date;
	}
	public OurOrigin(int our_origin_id, String our_origin_h_img_path, String our_origin_b_img_path, String origin_text,
			int created_by, Date created_date, int update_by, Date update_date) {
		this.our_origin_id = our_origin_id;
		this.our_origin_h_img_path = our_origin_h_img_path;
		this.our_origin_b_img_path = our_origin_b_img_path;
		this.origin_text = origin_text;
		this.created_by = created_by;
		this.created_date = created_date;
		this.update_by = update_by;
		this.update_date = update_date;
	}
	

}
//CREATE TABLE `rashikbhita`.`our_origin` (
//		  `our_origin_id` INT NOT NULL,
//		  `our_origin_h_img_path` VARCHAR(255) NULL,
//		  `our_origin_b_img_path` VARCHAR(255) NOT NULL,
//		  `origin_text` VARCHAR(255) NULL,
//		  `created_by` INT(11) NULL,
//		  `created_date` DATETIME(6) NULL,
//		  `update_by` INT(11) NULL,
//		  `update_date` DATETIME(6) NULL,
//		  PRIMARY KEY (`our_origin_id`));
