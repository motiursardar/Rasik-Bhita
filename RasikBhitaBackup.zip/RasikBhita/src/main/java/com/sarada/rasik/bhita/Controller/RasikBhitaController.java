package com.sarada.rasik.bhita.Controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import javax.persistence.OneToMany;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sarada.rasik.bhita.entity.AdvisoryCommittee;
import com.sarada.rasik.bhita.entity.AllCourseFee;
import com.sarada.rasik.bhita.entity.ContactDakshineswar;
import com.sarada.rasik.bhita.entity.CourseDetails;
import com.sarada.rasik.bhita.entity.CourseGroup;
import com.sarada.rasik.bhita.entity.Courses;
import com.sarada.rasik.bhita.entity.CoursesFees;
import com.sarada.rasik.bhita.entity.MasterManu;
import com.sarada.rasik.bhita.entity.OurOrigin;
import com.sarada.rasik.bhita.entity.Pages;
import com.sarada.rasik.bhita.entity.Premises;
import com.sarada.rasik.bhita.entity.StoryOfRasik;
import com.sarada.rasik.bhita.entity.SubMenu;
import com.sarada.rasik.bhita.repository.AdvisoryCommitteeRepo;
import com.sarada.rasik.bhita.repository.Contact_Repo;
import com.sarada.rasik.bhita.repository.CoursesFeesRepo;

import com.sarada.rasik.bhita.repository.CoursesRepo;
import com.sarada.rasik.bhita.repository.ImgStoryRepo;
import com.sarada.rasik.bhita.repository.MasterManuRepo;
import com.sarada.rasik.bhita.repository.OurOriginRepo;
import com.sarada.rasik.bhita.repository.PremisesRepo;
import com.sarada.rasik.bhita.service.RasikBhitaServiceImpl;

@RestController
public class RasikBhitaController {

	// MULTIPLE ENTITY WITH ID

	@Autowired
	RasikBhitaServiceImpl rasikBhitaServiceImpl;
	@Autowired
	CoursesFeesRepo coursesFeesRepo;
	@Autowired
	CoursesRepo coursesRepo;
	@Autowired
	MasterManuRepo masterManuRepo;
	@Autowired
	Contact_Repo contact_Repo;

	@GetMapping("/homepagedata/{page_id}")
	public ResponseEntity<Pages> getstudents(@PathVariable Integer page_id) {
		Optional<Pages> allHomePageData = rasikBhitaServiceImpl.gethomePageData(page_id);
		if (allHomePageData.isPresent()) {
			return new ResponseEntity<Pages>(allHomePageData.get(), HttpStatus.FOUND);
		} else {
			return new ResponseEntity<Pages>(HttpStatus.NOT_FOUND);
		}
	}

	////////////////////////////////////////////////////

	// MULTIPLE ENTITY

	@GetMapping("/CoursesFees")
	public ResponseEntity<List<CoursesFees>> findEntitiesWithJoin() {

		List<CoursesFees> coursesFeesob = new ArrayList<>();
		rasikBhitaServiceImpl.findEntitiesWithJoin().forEach(coursesFeesob::add);
		return new ResponseEntity<List<CoursesFees>>(coursesFeesob, HttpStatus.OK);
	}

	///////////////////////////////////////////////////////////////

	// FOR SINGLE ENTITY

	@GetMapping("/Courses")
	public ResponseEntity<List<Courses>> getAllcourses() {
		List<Courses> courseListOb = new ArrayList<>();
		coursesRepo.findAll().forEach(courseListOb::add);
		return new ResponseEntity<List<Courses>>(courseListOb, HttpStatus.OK);
	}

	@GetMapping("/CoursesDetails/{course_id}")

	public ResponseEntity<List<CourseDetails>> FinndCourseDetailsByCourseId(@PathVariable int course_id) {
		List<CourseDetails> courseDetailsOb = new ArrayList<>();
		rasikBhitaServiceImpl.FinndCourseDetailsByCourseId(course_id).forEach(courseDetailsOb::add);
		return new ResponseEntity<List<CourseDetails>>(courseDetailsOb, HttpStatus.OK);
	}
	//////////////////////////////////////////////////////////////////////////////////

	@GetMapping("/CoursesFees/{course_id}")

	public ResponseEntity<List<CoursesFees>> FinndCourseFeesByCourseId(@PathVariable int course_id) {
		List<CoursesFees> courseFeesOb = new ArrayList<>();
		rasikBhitaServiceImpl.FinndCourseFeesByCourseId(course_id).forEach(courseFeesOb::add);
		return new ResponseEntity<List<CoursesFees>>(courseFeesOb, HttpStatus.OK);
	}
	////////////////////////////////////////////////////////////////////////

	@GetMapping("/CourseGroup")
	public ResponseEntity<List<CourseGroup>> getAllcourseGroup() {
		List<CourseGroup> courseListOb = rasikBhitaServiceImpl.getAllcourseGroup();
		return new ResponseEntity<List<CourseGroup>>(courseListOb, HttpStatus.OK);
	}

	///////////////////////////////////////////////
	@Autowired
	private ImgStoryRepo imgStoryRepo;

	@GetMapping("/StoryOfRasik")
	public ResponseEntity<List<StoryOfRasik>> getAllStory() {
		List<StoryOfRasik> storyListOb = new ArrayList<>();
		imgStoryRepo.findAll().forEach(storyListOb::add);
		return new ResponseEntity<List<StoryOfRasik>>(storyListOb, HttpStatus.OK);
	}

	////////////////////////////////////////////////////////////////
	@Autowired
	private PremisesRepo premisesRepo;

	@GetMapping("/premises")
	public ResponseEntity<List<Premises>> getAllPremises() {
		List<Premises> PremisesListOb = new ArrayList<>();
		premisesRepo.findAll().forEach(PremisesListOb::add);

		return new ResponseEntity<List<Premises>>(PremisesListOb, HttpStatus.OK);
	}

////	@Autowired
////	private PremisesRepo premisesRepo;
//
//	@GetMapping("/premises")
//	public ResponseEntity<List<Premises>> getAllPremises() {
//		List<Premises> PremisesListOb = new ArrayList<>();
//		rasikBhitaServiceImpl.getAllPremises().forEach(PremisesListOb::add);
//		return new ResponseEntity<List<Premises>>(PremisesListOb, HttpStatus.OK);
//	}

	////////////////////////////////////////////////////////////////////////////////////
//
//	@Autowired
//	private OurOriginRepo ourOriginRepo;
//
//	@GetMapping("/OurOrigin")
//	public ResponseEntity<List<OurOrigin>> getAllOurOrigin() {
//		List<OurOrigin> OurOriginListOb = new ArrayList<>();
//		ourOriginRepo.findAll().forEach(OurOriginListOb::add);
//		return new ResponseEntity<List<OurOrigin>>(OurOriginListOb, HttpStatus.OK);
//	}
////////////////////////////////////////////////////////////////////////////////////////////
//
//	@Autowired
//	private AdvisoryCommitteeRepo advisoryCommitteeRepo;
//
//	@GetMapping("/AdvisoryCommittee")
//	public ResponseEntity<List<AdvisoryCommittee>> getAllAdvisoryCommittee() {
//		List<AdvisoryCommittee> AdvisoryCommitteeListOb = new ArrayList<>();
//		advisoryCommitteeRepo.findAll().forEach(AdvisoryCommitteeListOb::add);
//		return new ResponseEntity<List<AdvisoryCommittee>>(AdvisoryCommitteeListOb, HttpStatus.OK);
//	}
	/////////////////////////////////////////////////////////////////////////////////////////

	@PostMapping("/premises") /// Create Entity
	public String CreatePremises(@RequestBody Premises premisesOb) {
		premisesRepo.save(premisesOb);

		return "Insert Success";
	}

	/////////////////////////////////// UPDATE
	@PutMapping("/premises/{Premises_id}")
	public String updatePremisesById(@PathVariable int Premises_id, @RequestBody Premises premises) {
		Optional<Premises> premis = premisesRepo.findById(Premises_id);

		if (premis != null && premis.isPresent()) {

			Premises ExistingPremises = premis.get();
			ExistingPremises.setPremises_id(premises.getPremises_id());
			ExistingPremises.setPremises_h_img_path(premises.getPremises_h_img_path());
			ExistingPremises.setPremises_b_img_path(premises.getPremises_b_img_path());
			ExistingPremises.setPremises_text(premises.getPremises_text());
			ExistingPremises.setCreated_by(premises.getCreated_by());
			ExistingPremises.setCreated_date(premises.getCreated_date());
			ExistingPremises.setUpdate_by(premises.getUpdate_by());
			ExistingPremises.setUpdate_date(premises.getUpdate_date());
			premisesRepo.save(ExistingPremises);
			return "Premises id inserted" + Premises_id + "updated";

		} else {
			return "Premises id inserted not exist" + " " + Premises_id;
		}
	}

	/////////////////////////////////////////////////////////////////////////////// DALETE
	@DeleteMapping("/premises/{Premises_id}")
	public String deletePremisesById(@PathVariable int Premises_id) {
		premisesRepo.deleteById(Premises_id);
		return "Delete successfully";
	}
	////////////////////////////////////////////////////////////////

	@GetMapping("/AllCourseFee")

	public ResponseEntity<List<AllCourseFee>> FinndAllFee() {
		List<AllCourseFee> AllCourseFeeOb = new ArrayList<>();
		rasikBhitaServiceImpl.FinndAllCourseFee().forEach(AllCourseFeeOb::add);
		return new ResponseEntity<List<AllCourseFee>>(AllCourseFeeOb, HttpStatus.OK);
	}
/////////////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////
	// DEVELOP By Motiur Rahaman Sardar @OneToMany

	@GetMapping("/mastermanuandsub/{menu_id}")
	public ResponseEntity<List<MasterManu>> getMenuAndSubData(@PathVariable Integer menu_id) {
		List<MasterManu> allMasterManuData = rasikBhitaServiceImpl.getmastermanuAndSubData(menu_id);

		if (allMasterManuData != null) {
			return new ResponseEntity<List<MasterManu>>(allMasterManuData, HttpStatus.FOUND);
		} else {
			return new ResponseEntity<List<MasterManu>>(HttpStatus.NOT_FOUND);

		}
	}

	///////////////////////////////////////////////////////////
	@PostMapping("/CreateMenuAndSubmenu") /// Create Entity
	public String CreateSubMenu(@RequestBody SubMenu subMenuOb) {
		masterManuRepo.save(subMenuOb);

		return "Insert subMenuOb";
	}

	////////////////////////////////////////////////////////// 

	

	@GetMapping("/AllContact/{contactid}")
	public ResponseEntity<List<ContactDakshineswar>> getContactDakshineswar(@PathVariable Integer contactid) {
		List<ContactDakshineswar> contactDakshineswarob = rasikBhitaServiceImpl.getContactDakshineswar(contactid);

		if (contactDakshineswarob != null) {
			return new ResponseEntity<List<ContactDakshineswar>>(contactDakshineswarob, HttpStatus.FOUND);
		} else {
			return new ResponseEntity<List<ContactDakshineswar>>(HttpStatus.NOT_FOUND);

		}
	}
	/////////////////////////////////////////////////////////////////////////////////
	
	
	@PutMapping("/DakshineswarContact/{contactid}")
	public String updateContactDakshineswar(@PathVariable int contactid, @RequestBody ContactDakshineswar contactDakshineswar) {
		Optional<ContactDakshineswar> contact = contact_Repo.findById(contactid);

		if (contact != null && contact.isPresent()) {

			ContactDakshineswar ExistingContact = contact.get();
			ExistingContact.setContactid(contactDakshineswar.getContactid());
			ExistingContact.setOffice_Location(contactDakshineswar.getOffice_Location());
			ExistingContact.setContact_Number(contactDakshineswar.getContact_Number());
			ExistingContact.setOfficial_Emailaddress(contactDakshineswar.getOfficial_Emailaddress());
			ExistingContact.setContacthedimg(contactDakshineswar.getContacthedimg());
			ExistingContact.setAdmission_Course_Related_Queries(contactDakshineswar.getAdmission_Course_Related_Queries());
			ExistingContact.setVisitinghours(contactDakshineswar.getVisitinghours());
			ExistingContact.setCreated_by(contactDakshineswar.getCreated_by());
			ExistingContact.setCreated_date(contactDakshineswar.getCreated_date());
			ExistingContact.setUpdate_by(contactDakshineswar.getUpdate_by());
			ExistingContact.setUpdate_date(contactDakshineswar.getUpdate_date());
			contact_Repo.save(ExistingContact);
			return "Contact id inserted" + contactid + "updated";

		} else {
			return "Contact id inserted not exist" + " " + contactid;
		}
	}
}
